const { sleep } = require("./sleep");

async function sendMsg(data, number) {
  try {
    if (!number.contains("@c.us")) number = number + "@c.us";
    let msgOptions;
    let isFile = false;
    let fileSent;
    try {
      let msgRes;
      if (data.media != "") {
        isFile = true;
        const { file, fileType, filename } = data.media;
        fileSent = file;
        convert = {
          "&#96;": "`",
          "&quot;": '"',
          "&apos;": "'",
        };
        data.caption = data.caption.replace(
          /&#96;|&quot;|&apos;/g,
          function (m) {
            return convert[m];
          }
        );
        sleep(1500);
        msgOptions = {
          type: fileType,
          caption: data.caption,
          filename: filename,
          createChat: true,
          delay: 500,
        };
        msgRes = await window.WPP.chat.sendFileMessage(
          number,
          file,
          msgOptions
        );
      } else {
        msgOptions = {
          delay: 500,
          createChat: true,
        };
        msgRes = await window.WPP.chat.sendTextMessage(
          number,
          data.caption,
          msgOptions
        );
      }
      const res = await msgRes.sendMsgResult;
      if (res.messageSendResult == "OK") {
        // console.log("Message sent to " + number, "msg res", msgRes);
        return true;
      }
    } catch (error) {
      console.log("error on send msg", error);
    }
  } catch (error) {
    console.log("error on send msg 2", error);
    return false;
  }
}

module.exports = { sendMsg };
