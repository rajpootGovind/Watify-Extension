const WPP = require("@wppconnect/wa-js");
const {
  _init_,
  shootBulkCamp,
  shootMsg,
  manageActiveChat,
} = require("./extension/_init_");
const { manageBlur, toggleTheme } = require("../dist/js/tools");
const { sendMsg } = require("./extension/sendMsg");

let userPhone;
let activeChatBots = [];
let activeFlowCharts = [];
let availableTemplates = [];
let userPlan = {};

// Add webVersionCache configuration here
window.WPP.webVersionCache = {
  type: "remote",
  remotePath:
    "https://raw.githubusercontent.com/wppconnect-team/wa-version/main/html/2.3000.1014590669-alpha.html",
};

window.WPP.webpack.onInjected(() => {
  // console.log("injected wpp");
});
window.WPP.webpack.onFullReady(() => {
  console.log("full ready");
  const userIdObj = window.WPP.conn.getMyUserId();
  userPhone = userIdObj._serialized.toString();
  let customInterval = setInterval(() => {
    const app = document.querySelector("#app");
    if (app != undefined && app != null) {
      clearInterval(customInterval);
      // console.log("full ready");
      _init_(window.WPP);
    }
  }, 1000);
});

window.WPP.webpack.onReady(() => {
  console.log("ready");
});

window.addEventListener("message", async (event) => {
  // console.log("message received in bundle.js", event.data);
  if (event.origin === "https://web.whatsapp.com") {
    try {
      if (event.data.action === "triggerWebhookFunction") {
        let body = event.data.body;
        // console.log("Webhook data received in bundle.js:", body);
        let trigger_client_id = body.client_id;
        let client_encoded = body.client_encoded ?? 0;
        if (client_encoded == 1) {
          trigger_client_id = atob(body.client_id);
        }
        if (
          trigger_client_id == undefined ||
          trigger_client_id == null ||
          trigger_client_id == ""
        )
          return;
        if (!trigger_client_id.includes("@"))
          trigger_client_id = trigger_client_id + "@c.us";
        try {
          if (body.action === "flowcharts") {
            checkMsgInFlowcharts(body.trigger_key, trigger_client_id);
          } else if (body.action === "chatbots") {
            checkMsgInChatBot(body.trigger_key, trigger_client_id);
          } else if (body.action === "sendSingleMsgTemplate") {
            let template_id = body.template_id;
            let template = availableTemplates.find(
              (data) => data.temp_slug == template_id
            );
            if (template) {
              let msgData = {};
              msgData["caption"] = template.caption;
              msgData["template_id"] = body.template_id;
              if (template.media != "") {
                msgData.media = {
                  file: template.media.file,
                  fileType: template.media.fileType,
                  filename: template.media.filename,
                };
              }
              console.log(msgData, "msgData on bundle.js");
              await sendSingleMsgTemplate(
                msgData,
                trigger_client_id.split("@")[0]
              );
            }
          }
        } catch (error) {
          console.log(
            "Error occurred while checking message through webhook in bundle.js:",
            error
          );
        }
      }
      const message = event.data.message;
      if (message?.manageUi) {
        // console.log("manage ui", message.manageUi);
        const ui = message.manageUi.ui;
        if (ui == "darkMode") toggleTheme(false, message.manageUi.value);
        else manageBlur(ui, message.manageUi.value);
      }
      if (message?.sendMsg) {
        if (message.sendMsg == "BulkCamp") handleBulkCamp(message);
        if (message.sendMsg == "ShootMsg") handleShootMsg(message);
      }
      if (message?.saveToken) {
        localStorage.setItem("watifyToken", message.saveToken);
        // console.log("token saved", message.saveToken);
        if (activeChatBots.length == 0) {
          window.postMessage({ fetchChatBots: message.saveToken }, "*");
        }
        if (activeFlowCharts.length == 0) {
          window.postMessage({ fetchFlowCharts: message.saveToken }, "*");
        }
        if (availableTemplates.length == 0) {
          window.postMessage({ messageTemplates: message.saveToken }, "*");
        }
      }
      if (message?.chatBots) {
        activeChatBots = message.chatBots;
        console.log("activeChatBots Changed", activeChatBots);
      }
      if (message?.fetchChatBots) {
        // console.log("fetchChatBots", message.fetchChatBots);
        window.postMessage(
          { fetchChatBots: localStorage.getItem("watifyToken") },
          "*"
        );
      }
      if (message?.flowCharts) {
        activeFlowCharts = message.flowCharts;
        console.log("activeFlowCharts Changed", activeFlowCharts);
      }
      if (message?.fetchFlowCharts) {
        // console.log("fetchFlowCharts", message.fetchFlowCharts);
        window.postMessage(
          { fetchFlowCharts: localStorage.getItem("watifyToken") },
          "*"
        );
      }
      if (message?.messageTemplates) {
        // console.log("messageTemplates", message.messageTemplates);
        window.postMessage(
          { templates: localStorage.getItem("watifyToken") },
          "*"
        );
      }
      if (message?.templates) {
        availableTemplates = message.templates;
        console.log("active templates Changed", availableTemplates);
      }

      if (message?.shootSingleMsg) {
        console.log("shootSingleMsg", message.shootSingleMsg);
        shootMsg(message.shootSingleMsg);
      }

      if (message?.setUserPlan) {
        userPlan = message.setUserPlan;
        // console.log("user plan set", userPlan);
      }
    } catch (error) {
      // console.log(":error on message", error);
    }
  }
});

window.WPP.on("chat.active_chat", manageActiveChat);

async function sendSingleMsgTemplate(msgData, from) {
  try {
    const token = localStorage.getItem("watifyToken");
    if (!token) return;
    let formData = new FormData();
    formData.append("token", token);
    formData.append("shootMsgPhone", `${from}`);
    formData.append("shootMsgCaption", `${msgData.caption}`);
    formData.append("template_id", msgData.template_id);

    formData = Object.fromEntries(formData.entries());

    let template = availableTemplates.find(
      (data) => data.temp_slug == msgData.template_id
    );

    window.postMessage(
      {
        sendSingleMsgTemplate: {
          sendSingleMsgTemplate: 1,
          formData: formData,
          template: template,
          media: msgData.media,
          token: localStorage.getItem("watifyToken"),
        },
      },
      "*"
    );
  } catch (error) {
    console.log("error on sendSingleMsgTemplate", error);
  }
}

async function checkMsgInChatBot(message, from) {
  try {
    // console.log("activeChatBots", activeChatBots);
    // console.log("userPlan",userPlan);

    // console.log("message", message);
    // console.log(activeChatBots, "checkMsgInChatBot");

    if (activeChatBots.length == 0) return;
    if (
      Number(userPlan.totalSend) >= Number(userPlan.msg_limit) ||
      userPlan.msg == "Plan Expired"
    )
      return;
    activeChatBots.forEach((data) => {
      // console.log("data", data);
      let { keyword, keyword_type } = data;
      const msg = message?.toLowerCase().trim();
      const keywordArr = keyword.split(",");
      keywordArr.forEach(async (key) => {
        // console.log(key);
        const keyword = key?.toLowerCase().trim();
        if (keyword == "") return;
        if (
          (keyword_type == "keyword" && msg == keyword) ||
          (keyword_type == "string" && msg.includes(keyword))
        ) {
          const msgData = {
            caption: data.msg_caption,
            media: data.msg_media,
          };
          const sendRes = await sendMsg(msgData, from);
          if (sendRes) {
            userPlan.totalSend = Number(userPlan.totalSend) + 1;
            window.postMessage(
              {
                updateChatBot: {
                  slug: data.bot_id,
                  total: 1,
                  send: 1,
                  failed: 0,
                  sender: "chatbot_data",
                  token: localStorage.getItem("watifyToken"),
                  saveAnalytics: 1,
                },
              },
              "*"
            );
          }
        }
      });
    });
  } catch (error) {
    // console.log("error on chat bot", error);
  }
}

function findNode(data, type = "starting") {
  for (let key in data) {
    if (data[key].type === type) {
      return data[key];
    }
  }
  return null; // If type is not found
}

// Helper to send a node message & update state
async function sendNodeMessage(
  from,
  slug,
  node,
  allNodes,
  flowData,
  isStarting = false
) {
  const options = node.options || {};
  let caption = node.message;

  if (Object.keys(options).length) {
    caption += "\n";
    if (isStarting) caption += "\nChoose an option:";
    Object.keys(options)
      .sort((a, b) => b.length - a.length)
      .forEach((opt) => (caption += `\n- ${opt}`));
  }

  const msgData = { caption: caption.trim(), media: "" };
  const sendRes = await sendMsg(msgData, from);

  if (sendRes) {
    userPlan.totalSend = Number(userPlan.totalSend) + 1;
    window.postMessage(
      {
        updateFlowChart: {
          slug,
          total: 1,
          send: 1,
          failed: 0,
          sender: "flowcharts",
          token: localStorage.getItem("watifyToken"),
          saveAnalytics: 1,
        },
      },
      "*"
    );

    if (!flowData[from]) flowData[from] = {};
    flowData[from][slug] = {
      current_node: node.id,
      message: node.message,
      type: node.type,
      options: node.options,
    };
  }
}

async function checkMsgInFlowcharts(message, from) {
  // console.log("checkMsgInFlowcharts", message, from, activeFlowCharts);

  try {
    if (
      !activeFlowCharts.length ||
      Number(userPlan.totalSend) >= Number(userPlan.msg_limit) ||
      userPlan.msg === "Plan Expired"
    )
      return;

    const msg = message?.toLowerCase().trim();
    const onGoingFlowchart =
      JSON.parse(localStorage.getItem("onGoingFlowchart")) || {};

    for (const data of activeFlowCharts) {
      const { trigger_key, all_nodes: allNodesRaw, slug } = data;
      const triggerKeys = trigger_key
        ?.split(",")
        ?.map((k) => k?.toLowerCase().trim());
      const allNodes = JSON.parse(allNodesRaw);

      let flowState = onGoingFlowchart[from]?.[slug];
      let matchedTrigger = triggerKeys?.includes(msg);

      // checking new flowchart trigger
      if (matchedTrigger) {
        const startNode = findNode(allNodes, "starting");
        if (!startNode) continue;

        await sendNodeMessage(
          from,
          slug,
          startNode,
          allNodes,
          onGoingFlowchart,
          true
        );
        continue;
      }

      // checking ongoing flowchart
      if (flowState && flowState.options) {
        const matchedOption = Object.keys(flowState.options).find(
          (key) => key?.toLowerCase().trim() === msg
        );

        if (matchedOption) {
          const nextNodeId = flowState.options[matchedOption]?.[0];
          if (!nextNodeId) {
            delete onGoingFlowchart[from][slug]; // Flow ended
          } else {
            const nextNode = allNodes[nextNodeId];
            if (nextNode)
              await sendNodeMessage(
                from,
                slug,
                nextNode,
                allNodes,
                onGoingFlowchart
              );
          }
        }
      }
    }

    // Save updated flowchart state
    localStorage.setItem("onGoingFlowchart", JSON.stringify(onGoingFlowchart));
  } catch (error) {
    console.error("Error in checkMsgInFlowcharts:", error);
  }
}

window.WPP.on("chat.new_message", async (msg) => {
  try {
    if (msg.from._serialized == userPhone || msg.user == "status") return;
    // console.log("msg reveiced", msg.body, msg.from);
    checkMsgInChatBot(msg.body, msg.from._serialized);
    checkMsgInFlowcharts(msg.body, msg.from._serialized);
  } catch (error) {
    // console.log("error on chat.new_message", error);
  }
});

const handleBulkCamp = (payload) => {
  console.log(payload, "payload in bundle.js");

  let templateData = availableTemplates.find(
    (data) => data.temp_slug == payload.value["messageTemplates"]
  );

  console.log(templateData, "templateData");

  // if (templateData) {
  //   payload.value["bulkCampMsg"] = templateData["msg"];
  // }

  const bulkData = {
    contacts: payload.value["contacts"],
    caption: templateData["caption"],
    media: "",
    slug: payload.value["bulkSlug"],
  };

  if (templateData.media != "") {
    bulkData.media = {
      file: templateData.media.file,
      fileType: templateData.media.fileType,
      filename: templateData.media.filename,
    };
  }

  console.log(bulkData, "bulkData");
  shootBulkCamp(bulkData);
};

const handleShootMsg = (payload) => {
  console.log(payload, "payload in bundle.js");

  let templateData = availableTemplates.find(
    (data) => data.temp_slug == payload.value["messageTemplates"]
  );

  console.log(templateData, "templateData");

  // if (templateData) {
  //   payload.value["bulkCampMsg"] = templateData["msg"];
  // }

  const sendMsgData = {
    contacts: payload.value["shootMsgPhone"],
    caption: templateData["caption"],
    media: "",
    slug: payload.value["slug"],
  };

  console.log(sendMsgData, "sendMsgData before media");

  if (templateData.media != "") {
    sendMsgData.media = {
      file: templateData.media.file,
      fileType: templateData.media.fileType,
      filename: templateData.media.filename,
    };
  }

  console.log(sendMsgData, "sendMsgData");
  shootMsg(sendMsgData);
};
