chrome.runtime.setUninstallURL(
  "https://watify.io/feedback?user=" + chrome.runtime.id
);
