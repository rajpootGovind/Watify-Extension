function getUserInfo() {
  const info = localStorage.getItem("userInfo");
  let userInfo;
  if (info) userInfo = JSON.parse(info);
  else {
    userInfo = {
      userName: "",
      userPhone: {
        phone: "",
        _serialized: "",
      },
      status: {
        blurMessages: false,
        blurProfile: false,
        blurUserNames: false,
        blurConversation: false,
        theme: "dark",
      },
    };
    localStorage.setItem("userInfo", JSON.stringify(userInfo));
  }
  return userInfo;
}

function setUserInfo(WPP) {
  //set user Info
  const userInfo = getUserInfo();
  // console.log("set user", userInfo);
  const userIdObj = WPP.conn.getMyUserId();
  userInfo.userPhone.__serialized = userIdObj._serialized.toString();
  userInfo.userPhone.phone = userIdObj.user.toString();
  userInfo.userName = WPP.profile.getMyProfileName();

  localStorage.setItem("userInfo", JSON.stringify(userInfo));
  localStorage.setItem("watifyToken", btoa(userInfo.userPhone.__serialized));
}

function setUserStatus(key, value) {
  const userInfo = getUserInfo();
  const userStatus = userInfo.status;
  userStatus[key] = value;
  localStorage.setItem("userInfo", JSON.stringify(userInfo));
}

async function fetchUserPlan(token = "") {
  if (token == "") token = localStorage.getItem("watifyToken");

  // console.log(token, "token in user plan");
  const response = await fetch(
    `https://watify.io/checkPlan?fetchUserPlan=1&token=${token}`,
    {
      method: "GET",
    }
  );

  const data = await response.text();
  return JSON.parse(data);
}

export { getUserInfo, setUserStatus, setUserInfo, fetchUserPlan };
