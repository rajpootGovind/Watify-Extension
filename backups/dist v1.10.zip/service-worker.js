const user = {
  username: "demo-user",
};

chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  // console.log("inside worker ");
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    chrome.tabs.sendMessage(tabs[0].id, message, (response) => {
      sendResponse(response);
    });
  });

  return true; // Indicate that the response will be sent asynchronously
});
