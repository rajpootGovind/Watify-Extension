
(() => {
  // console.log("chrome runtime", chrome.runtime);
  chrome.runtime.onMessage.addListener(
    async (message, sender, sendResponse) => {
      // console.log("inside worker ", window.WPP, message);
      if (message.type === "initPopup") {
        // console.log("user info", message.data);
        return;
      }
      if (message.manageUi) {
        // console.log("manage ui", message.manageUi);
        const ui = message.manageUi.ui;
        // if (ui == "darkMode") toggleTheme();
        // else manageBlur(ui, message.manageUi.value);
      }
      try {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          chrome.tabs.sendMessage(tabs[0].id, message, (response) => {
            sendResponse(response);
          });
        });
      } catch (error) {
        // console.log("error on message listener");
      }

      return true; // Indicate that the response will be sent asynchronously
    }
  );
})();
