import { manageBlur } from "../../dist/js/tools";
import { getUserInfo, setUserInfo } from "../../dist/js/userInfo";
import { sendMsg } from "./sendMsg";
import { sleep } from "./sleep";

function changeTheme() {
  let userInfo = localStorage.getItem("userInfo");
  userInfo = JSON.parse(userInfo);

  const whatsappBody = document.querySelector("body");
  const theme = userInfo?.status?.theme;
  if (theme === "dark" && whatsappBody.classList.contains("dark") === false)
    whatsappBody.classList.add("dark");
  else if (
    theme === "light" &&
    whatsappBody.classList.contains("dark") === true
  )
    whatsappBody.classList.remove("dark");
}

function _init_(WPP) {
  // console.log("_init_");
  setUserInfo(window.WPP);
  changeTheme();
  const userInfo = getUserInfo();
  console.log(userInfo, "userInfo");
  const userStatus = userInfo.status;
  if (userStatus.blurUserNames) manageBlur("blurUserNames", true);
  if (userStatus.blurProfile) manageBlur("blurProfile", true);
  if (userStatus.blurMessages) manageBlur("blurMessages", true);

  window.postMessage(
    { loginUser: { phone: userInfo.userPhone.phone, name: userInfo.userName } },
    "*"
  );
}

async function shootBulkCamp(message) {
  console.log(message, "shootBulkCamp");
  let send = 0;
  let failed = 0;
  try {
    const numbers = message.contacts.split(",");

    console.log(message, "shootBulkCamp MESSAGE");

    // console.log(numbers, "numbers");
    for (const number of numbers) {
      // console.log("number", number);
      const isSent = await sendMsg(message, number);
      if (isSent) send++;
      else failed++;
      await sleep(2500);
    }

    console.log("send", send, "failed", failed);

    window.postMessage(
      {
        updateBulkCamp: {
          saveBulkAnalytics: 1,
          slug: message.slug,
          total: numbers.length,
          send,
          failed,
          token: localStorage.getItem("watifyToken"),
        },
      },
      "*"
    );
  } catch (error) {
    // console.log("errro on bulk camp", error);
  }
}
async function shootMsg(message) {
  let send = 0;
  let failed = 0;
  try {
    const number = message.contacts + "@c.us";
    const isSent = await sendMsg(message, number);
    if (isSent) send++;
    else failed++;

    window.postMessage(
      {
        updateShootMsg: {
          saveShootMsgAnalytics: 1,
          slug: message.slug,
          total: 1,
          send,
          failed,
          token: localStorage.getItem("watifyToken"),
        },
      },
      "*"
    );
    // console.log("posted message");
  } catch (error) {
    // console.log("error on bulk camp", error);
  }
}

function manageActiveChat() {
  const userStatus = getUserInfo().status;
  if (userStatus.blurUserNames) manageBlur("blurUserNames", true);
  if (userStatus.blurProfile) manageBlur("blurProfile", true);
  if (userStatus.blurConversation) manageBlur("blurConversation", true);
}

export { _init_, shootBulkCamp, shootMsg, manageActiveChat };
