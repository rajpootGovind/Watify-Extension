const WPP = require("@wppconnect/wa-js");
const {
  _init_,
  shootBulkCamp,
  shootMsg,
  manageActiveChat,
} = require("./extension/_init_");
const { manageBlur, toggleTheme } = require("../dist/js/tools");
const { sendMsg } = require("./extension/sendMsg");

let userPhone;
let activeChatBots = [];
let availableTemplates = [];
let userPlan = {};

// Add webVersionCache configuration here
window.WPP.webVersionCache = {
  type: 'remote',
  remotePath: 'https://raw.githubusercontent.com/wppconnect-team/wa-version/main/html/2.3000.1014590669-alpha.html'
};

window.WPP.webpack.onInjected(() => {
  // console.log("injected wpp");
});
window.WPP.webpack.onFullReady(() => {
  console.log("full ready");
  const userIdObj = window.WPP.conn.getMyUserId();
  userPhone = userIdObj._serialized.toString();
  let customInterval = setInterval(() => {
    const app = document.querySelector("#app");
    if (app != undefined && app != null) {
      clearInterval(customInterval);
      // console.log("full ready");
      _init_(window.WPP);
    }
  }, 1000);
});

window.WPP.webpack.onReady(() => {
  console.log("ready");
});



window.addEventListener("message", (event) => {
  // console.log("message on bundle", event.data);
  if (event.origin === "https://web.whatsapp.com") {
    try {
      const message = event.data.message;
      if (message?.manageUi) {
        // console.log("manage ui", message.manageUi);
        const ui = message.manageUi.ui;
        if (ui == "darkMode") toggleTheme(false, message.manageUi.value);
        else manageBlur(ui, message.manageUi.value);
      }
      if (message?.sendMsg) {
        if (message.sendMsg == "BulkCamp") handleBulkCamp(message);
        if (message.sendMsg == "ShootMsg") handleShootMsg(message);
      }
      if (message?.saveToken) {
        localStorage.setItem("watifyToken", message.saveToken);
        if (activeChatBots.length == 0) {
          window.postMessage({ fetchChatBots: message.saveToken }, "*");
        }
        if (availableTemplates.length == 0) {
          window.postMessage({ messageTemplates: message.saveToken }, "*");
        }
      }
      if (message?.chatBots) {
        activeChatBots = message.chatBots;
        console.log("activeChatBots Changed", activeChatBots);
      }
      if (message?.fetchChatBots) {
        // console.log("fetchChatBots", message.fetchChatBots);
        window.postMessage(
          { fetchChatBots: localStorage.getItem("watifyToken") },
          "*"
        );
      }
      if (message?.messageTemplates) {
        // console.log("messageTemplates", message.messageTemplates);
        window.postMessage(
          { messageTemplates: localStorage.getItem("watifyToken") },
          "*"
        );
      }
      if (message?.templates) {
        availableTemplates = message.templates;
        console.log("active templates Changed", availableTemplates);
      }
      if (message?.setUserPlan) {
        userPlan = message.setUserPlan;
        // console.log("user plan set", userPlan);
      }
    } catch (error) {
      // console.log(":error on message", error);
    }
  }
});

window.WPP.on("chat.active_chat", manageActiveChat);

async function checkMsgInChatBot(message, from) {
  try {
    // console.log("activeChatBots", activeChatBots);
    // console.log("userPlan",userPlan);

    // console.log("message", message);
    // console.log(activeChatBots, "checkMsgInChatBot");

    if (activeChatBots.length == 0) return;
    if (
      Number(userPlan.totalSend) >= Number(userPlan.msg_limit) ||
      userPlan.msg == "Plan Expired"
    )
      return;
    activeChatBots.forEach((data) => {
      // console.log("data", data);
      let { keyword, keyword_type } = data;
      const msg = message.toLowerCase().trim();
      const keywordArr = keyword.split(",");
      keywordArr.forEach(async (key) => {
        // console.log(key);
        const keyword = key.toLowerCase().trim();
        if (keyword == "") return;
        if (
          (keyword_type == "keyword" && msg == keyword) ||
          (keyword_type == "string" && msg.includes(keyword))
        ) {
          const msgData = {
            caption: data.msg_caption,
            media: data.msg_media,
          };
          const sendRes = await sendMsg(msgData, from);
          if (sendRes) {
            userPlan.totalSend = Number(userPlan.totalSend) + 1;
            window.postMessage(
              {
                updateChatBot: {
                  slug: data.bot_id,
                  total: 1,
                  send: 1,
                  failed: 0,
                  sender: "chatbot_data",
                  token: localStorage.getItem("watifyToken"),
                  saveAnalytics: 1,
                },
              },
              "*"
            );
          }
        }
      });
    });
  } catch (error) {
    // console.log("error on chat bot", error);
  }
}

window.WPP.on("chat.new_message", async (msg) => {
  try {
    if (msg.from._serialized == userPhone || msg.user == "status") return;
    // console.log("msg reveiced", msg.body, msg.from);
    checkMsgInChatBot(msg.body, msg.from._serialized);
  } catch (error) {
    // console.log("error on chat.new_message", error);
  }
});

const handleBulkCamp = (payload) => {
  console.log(payload, "payload in bundle.js");

  let templateData = availableTemplates.find(
    (data) => data.temp_slug == payload.value["messageTemplates"]
  );

  console.log(templateData, "templateData");

  // if (templateData) {
  //   payload.value["bulkCampMsg"] = templateData["msg"];
  // }

  const bulkData = {
    contacts: payload.value["contacts"],
    caption: templateData["caption"],
    media: "",
    slug: payload.value["bulkSlug"],
  };

  if (templateData.media != "") {
    bulkData.media = {
      file: templateData.media.file,
      fileType: templateData.media.fileType,
      filename: templateData.media.filename,
    };
  }

  console.log(bulkData, "bulkData");
  shootBulkCamp(bulkData);
};

const handleShootMsg = (payload) => {
  console.log(payload, "payload in bundle.js");

  let templateData = availableTemplates.find(
    (data) => data.temp_slug == payload.value["messageTemplates"]
  );

  console.log(templateData, "templateData");

  // if (templateData) {
  //   payload.value["bulkCampMsg"] = templateData["msg"];
  // }

  const sendMsgData = {
    contacts: payload.value["shootMsgPhone"],
    caption: templateData["caption"],
    media: "",
    slug: payload.value["slug"],
  };

  if (templateData.media != "") {
    sendMsgData.media = {
      file: templateData.media.file,
      fileType: templateData.media.fileType,
      filename: templateData.media.filename,
    };
  }

  console.log(sendMsgData, "sendMsgData");
  shootMsg(sendMsgData);
};
