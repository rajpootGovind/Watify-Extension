import { fetchUserPlan } from "../dist/js/userInfo";

// console.log("chrome runtime", chrome.runtime);
chrome.runtime.onMessage.addListener(async (message, sender, sendResponse) => {
  if (message.type === "initPopup") {
    // console.log("user info", message.data);
    return;
  }
  window.postMessage(message, "*");

  return true; // Indicate that the response will be sent asynchronously
});

let shivamsg = "shivamsg";

window.postMessage({ greeting: "Hello from index.js" }, "*");

async function saveAnalytics(data) {
  const res = await fetch("https://watify.io/fun/extFun/manageBulk", {
    method: "POST",
    body: JSON.stringify(data),
    headers: {
      "Content-Type": "application/json",
    },
  });
  return await res.text();
}

async function fetchChatBots(token) {
  let chatBotsRes = await fetch(
    `https://watify.io/fun/watifyExtApi?getChatbots=1&token=${token}&activeBots=1`
  );
  let chatBots = await chatBotsRes.text();
  chatBots = JSON.parse(chatBots);
  // console.log("cahtbots", chatBots);
  if (chatBots.status == 200) {
    for (let i = 0; i < chatBots.data.length; i++) {
      const bot = chatBots.data[i];
      // console.log("bot", bot);
      bot.msg_media = await convertUrlToFile(bot.msg_media);
      chatBots.data[i] = bot;
    }
    console.log("chatBots", chatBots.data);
    return chatBots.data;
  } else return false;
}

async function fetchMessageTemplate(token) {
  // let reloadTemplateBtn = document.querySelector(".refreshTemplates svg");
  // let reloadTempText = document.querySelector(".templatesRefreshText");
  // reloadTempText.innerText = "Refreshing...";
  // reloadTemplateBtn.classList.add("spin", "disabled");
  let messageTempRes = await fetch(
    `https://watify.io/fun/watifyExtApi?getMessageTemplate=1&token=${token}`
  );
  let messageTemp = await messageTempRes.text();
  // reloadTemplateBtn.classList.remove("spin", "disabled");
  // reloadTempText.innerText = "Refresh Templates";
  messageTemp = JSON.parse(messageTemp);
  console.log("messageTemp", messageTemp);
  if (messageTemp.status == 200) {
    for (let i = 0; i < messageTemp.data.length; i++) {
      const temp = messageTemp.data[i];
      // console.log("temp", temp);
      temp.media = await convertUrlToFile(temp.media);
      messageTemp.data[i] = temp;
    }
    console.log("messageTemp", messageTemp.data);

    updateTemplateSelector(messageTemp.data);

    return messageTemp.data;
  } else return false;
}

function updateTemplateSelector(templates) {
  const templateSelector = document.querySelectorAll(".messageTemplates");

  if (templateSelector.length == 0) return;

  templateSelector.forEach((selector) => {
    selector.innerHTML = "";
    if (templates.length == 0) {
      const option = document.createElement("option");
      option.value = "";
      option.disabled = true;
      option.selected = true;
      option.innerText = "No templates found, Add new template";
      selector.appendChild(option);
    }

    templates.forEach((temp) => {
      const option = document.createElement("option");
      option.value = temp.temp_slug;
      option.innerText = temp.name;
      selector.appendChild(option);
    });
  });
}

async function loginUser(phone, name) {
  const response = await fetch(
    `https://watify.io/checkPlan?loginUser=1&phone=${phone}&name=${name}`,
    {
      method: "GET",
    }
  );
  const data = await response.text();
  const userLogin = JSON.parse(data);
  const message = {
    saveToken: userLogin.instanceId,
  };
  window.postMessage({ message }, "*");

  const userPlan = await fetchUserPlan(userLogin.instanceId);
  window.postMessage({ message: { setUserPlan: userPlan } }, "*");
}

function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    if (!file) {
      reject(new Error("File is undefined"));
      return;
    }

    const reader = new FileReader();
    // console.log("reader", reader);
    reader.onload = () => {
      const base64 = reader.result; // Extract the base64 part
      const ext = file.name.split(".").pop().toLowerCase(); // Get the file extension
      const type = file.type; // Get the MIME type
      const filename = file.name; // Get the file name

      // console.log({ file: base64, ext, fileType: type, filename });
      resolve({ file: base64, ext, fileType: type, filename });
    };

    reader.onerror = (error) => {
      reject(error);
    };

    reader.readAsDataURL(file);
  });
}

async function convertUrlToFile(mediaUrl) {
  try {
    if (mediaUrl == "") return "";
    // Fetch the data from the URL
    const response = await fetch(`https://watify.io/mediaFiles/${mediaUrl}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
      mode: "cors",
    });
    // Check if the request was successful
    if (!response.ok) {
      throw new Error(`Failed to fetch the URL: ${response}`);
    }
    // Convert the response to a Blob
    const blob = await response.blob();

    // Extract the filename from the URL
    const urlParts = mediaUrl.split("/");
    const filename = urlParts[urlParts.length - 1];

    // Create a File object from the Blob
    const file = new File([blob], filename, {
      type: blob.type,
    });

    return await fileToBase64(file);
  } catch (error) {
    console.error("Error creating file object:", error);
    return "";
  }
}

window.addEventListener("message", async (event) => {
  if (event.data.updateBulkCamp) {
    // console.log("update bulk camp", event.data.updateBulkCamp);
    const res = await saveAnalytics(event.data.updateBulkCamp);
    const data = JSON.parse(res);
    const campData = event.data.updateBulkCamp;
    if (data.status == 200) {
      // console.log("bulk analytics saved", data);
      chrome.runtime.sendMessage({
        type: "updateBulkCamp",
        data: campData,
      });

      saveAnalytics({
        saveAnalytics: 1,
        slug: campData.slug,
        total: campData.total,
        send: campData.send,
        failed: campData.failed,
        sender: "bulk_messenger",
        token: localStorage.getItem("watifyToken"),
      });
    }
  } else if (event.data.updateShootMsg) {
    // console.log("update shoot msg", event.data.updateShootMsg);
    const res = await saveAnalytics(event.data.updateShootMsg);
    // console.log("res msg", res);
    const data = JSON.parse(res);
    const campData = event.data.updateShootMsg;
    if (data.status == 200) {
      // console.log("shoot msg analytics saved", data);
      chrome.runtime.sendMessage({
        type: "updateShootMsg",
        data: campData,
      });

      saveAnalytics({
        saveAnalytics: 1,
        slug: campData.slug,
        total: campData.total,
        send: campData.send,
        failed: campData.failed,
        sender: "shoot_msg",
        token: localStorage.getItem("watifyToken"),
      });
    }
  } else if (event.data.fetchChatBots) {
    let chatBots = await fetchChatBots(event.data.fetchChatBots);
    console.log("chatBots media upddated", chatBots);
    window.postMessage({ message: { chatBots } }, "*");
  } else if (event.data.messageTemplates) {
    let templates = await fetchMessageTemplate(event.data.messageTemplates);
    console.log("template upddated", templates);
    window.postMessage({ message: { templates } }, "*");
  } else if (event.data.loginUser) {
    loginUser(event.data.loginUser.phone, event.data.loginUser.name);
  } else if (event.data.updateChatBot) {
    const res = await saveAnalytics(event.data.updateChatBot);
    // console.log("res analytics", res);
  }
});

document.addEventListener("DOMContentLoaded", async () => {
  let reloadTemplateBtn = document.querySelectorAll(".refreshTemplates");
  console.log("reloadTemplateBtn", reloadTemplateBtn);
  if (reloadTemplateBtn.length == 0) return;

  reloadTemplateBtn.forEach((btn) => {
    console.log("btn", btn);
    let reloadTemplateSVG = btn.querySelector("svg");
    let reloadTempText = btn.querySelector(".templatesRefreshText");
    console.log("reloadTempText", reloadTempText);
    btn.addEventListener("click", async () => {
      if (!reloadTempText) return;
      reloadTempText.classList.remove("d-none");
      reloadTempText.innerText = "Refreshing...";
      reloadTemplateSVG.classList.add("spin", "disabled");
      await fetchMessageTemplate(localStorage.getItem("watifyToken"));
      reloadTemplateSVG.classList.remove("spin", "disabled");
      reloadTempText.innerText = "Refreshed";
      setTimeout(() => {
        reloadTempText.classList.add("d-none");
      }, 1000);
      notifyForTemplate();
    });

    btn.click();
  });
});

async function notifyForTemplate() {
  const [tab] = await chrome.tabs.query({
    active: true,
    lastFocusedWindow: true,
  });
  await chrome.tabs.sendMessage(tab.id, {
    message: { messageTemplates: 1 },
  });
}
